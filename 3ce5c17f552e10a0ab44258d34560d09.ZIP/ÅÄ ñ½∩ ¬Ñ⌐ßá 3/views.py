from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.shortcuts import render, redirect
from .models import Post
from django.contrib.auth.decorators import login_required

@login_required
def create_post(request):
    if request.method == 'POST':
        title = request.POST['title']
        content = request.POST['content']
        tags = request.POST['tags']
        is_private = request.POST.get('is_private', False)
        post = Post.objects.create(title=title, content=content, author=request.user, is_private=is_private, tags=tags)
        return redirect('home')
    return render(request, 'create_post.html')
def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserCreationForm()
    return render(request, 'register.html', {'form': form})

def user_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

def user_logout(request):
    logout(request)
    return redirect('home')

def subscribe(request, user_id):
    user_to_subscribe = User.objects.get(id=user_id)
    Subscription.objects.create(user=request.user, subscribed_to=user_to_subscribe)
    return redirect('home')

def subscription_posts(request):
    subscriptions = Subscription.objects.filter(user=request.user)
    posts = Post.objects.filter(author__in=[sub.subscribed_to for sub in subscriptions], is_private=False)
    return render(request, 'subscription_posts.html', {'posts': posts})

def public_posts(request):
    posts = Post.objects.filter(is_private=False)
    return render(request, 'public_posts.html', {'posts': posts})

def request_private_post(request, post_id):
    post = Post.objects.get(id=post_id)
    if post.is_private:
        # Логика запроса доступа (например, через email или уведомление)
        pass
    return render(request, 'post_detail.html', {'post': post})

def edit_post(request, post_id):
    post = Post.objects.get(id=post_id)
    if request.user == post.author:
        if request.method == 'POST':
            post.title = request.POST['title']
            post.content = request.POST['content']
            post.tags = request.POST['tags']
            post.is_private = request.POST.get('is_private', False)
            post.save()
            return redirect('home')
        return render(request, 'edit_post.html', {'post': post})
    return redirect('home')

@login_required
def delete_post(request, post_id):
    post = Post.objects.get(id=post_id)
    if request.user == post.author:
        post.delete()
    return redirect('home')

def posts_by_tag(request, tag):
    posts = Post.objects.filter(tags__icontains=tag, is_private=False)
    return render(request, 'posts_by_tag.html', {'posts': posts})

def add_comment(request, post_id):
    if request.method == 'POST':
        content = request.POST['content']
        post = Post.objects.get(id=post_id)
        Comment.objects.create(post=post, author=request.user, content=content)
        return redirect('post_detail', post_id=post_id)