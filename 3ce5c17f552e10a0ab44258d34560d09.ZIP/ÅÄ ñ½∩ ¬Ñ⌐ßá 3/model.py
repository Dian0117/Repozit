{
 "cells": [
  {
   "cell_type": "markdown",
   "id": "41373519-1cc9-4c0b-bae6-451abcfdea2d",
   "metadata": {},
   "source": [
    "from django.contrib.auth.models import User\n",
    "from django.db import models\n",
    "from django.contrib.auth.models import User\n",
    "\n",
    "class Post(models.Model):\n",
    "    title = models.CharField(max_length=200)\n",
    "    content = models.TextField()\n",
    "    author = models.ForeignKey(User, on_delete=models.CASCADE)\n",
    "    is_private = models.BooleanField(default=False)\n",
    "    tags = models.CharField(max_length=200)\n",
    "    created_at = models.DateTimeField(auto_now_add=True)\n",
    "class Subscription(models.Model):\n",
    "    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='subscriber')\n",
    "    subscribed_to = models.ForeignKey(User, on_delete=models.CASCADE, related_name='subscribed_to')\n",
    "    created_at = models.DateTimeField(auto_now_add=True)\n",
    "\n",
    "class Comment(models.Model):\n",
    "    post = models.ForeignKey(Post, on_delete=models.CASCADE)\n",
    "    author = models.ForeignKey(User, on_delete=models.CASCADE)\n",
    "    content = models.TextField()\n",
    "    created_at = models.DateTimeField(auto_now_add=True)\n",
    "\n"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.12.2"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
