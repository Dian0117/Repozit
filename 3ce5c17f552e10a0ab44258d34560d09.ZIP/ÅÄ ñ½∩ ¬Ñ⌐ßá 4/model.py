from django.db import models

class Book(models.Model):
    CATEGORY_CHOICES = [
        ('Fiction', 'Fiction'),
        ('Non-Fiction', 'Non-Fiction'),
        ('Sci-Fi', 'Sci-Fi'),
        ('Fantasy', 'Fantasy'),
    ]

    title = models.CharField(max_length=200)
    author = models.CharField(max_length=100)
    year = models.IntegerField()
    category = models.CharField(max_length=100, choices=CATEGORY_CHOICES)
    price = models.DecimalField(max_digits=5, decimal_places=2)
    is_available = models.BooleanField(default=True)
    status = models.CharField(max_length=100, default="Available")
    rent_period = models.CharField(max_length=100, blank=True)

    def __str__(self):
        return self.title
from django.contrib.auth.models import User

class Rental(models.Model):
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    rent_start = models.DateField()
    rent_end = models.DateField()
    duration = models.CharField(max_length=20, choices=[('2 weeks', '2 weeks'), ('1 month', '1 month'), ('3 months', '3 months')])

